"""Ultrasonic sensor package."""
