"""Tapeinos sensor package."""
